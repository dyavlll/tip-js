"use strict";
const studentName = "Дьяков В. Н.";
const groupName = "ЭФБО-06-25";
const practiceNumber = 1;
console.log(`Студент: ${studentName}`);
console.log(`Группа: ${groupName}`);
console.log(`Практическая работа: ${practiceNumber}`);
console.log("JavaScript успешно запущен");
console.log("Тип document:", typeof document);
